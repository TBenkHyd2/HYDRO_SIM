close all; clc; clear all; %mise a jour de toutes les variables 
%  HYDRO_SIM: SIMULATION OF HYDROLOGICAL DATA  USING PRINCIPAL COMPONENT ANALYSIS & PROBABILISTIC MODEL %% 
% By N.DECHEMI & T. BENKACI 2020       ');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% READ DATA FROM EXCEL FILE LECTURE DES DONNEES                                                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[DATA,TEXT] = xlsread('FILE_RAINFALL.xlsx'); % DATA FILE: OBSERVED MONTHLY RAINFALL
V=DATA;
[L C] = size(V); %Dimensions of Matrix data --- Dimensions de la matrice
LG=L*C;

% SORTIE GRAPHIQUE
% 1=VARIABLES    2:RESIDUS   3: CP REDUITES
IGR=1;  % DATA TO DISPLAY ---- Donnees a afficher : Les variables simulees

%Important: % NUMBER OF DATA TO BE SIMULATED, and Number of Dimensions NCP
LS=70; % NUMBER OF DATA TO BE SIMULATED EXample: Simulation of 50, 80 or 100 data Years
NCP=4;% NUMBER OF DIMENSIONS = NUMBER OF COMPONENTS ARE ENOUGH TO REPRESENT THE DATA: MAX= Number of Variables
% the NUMBER OF DIMENSIONS depend on Data but let NCP =4
%%%%%% Number of max NCP
if NCP > C  % Nombre de CP Ne peut pas depasser le nombre de fariables
disp('NUMBER OF DIMENSIONS IS GRETAET THAN NUMBER OF VARIABLES ')
disp(' LE NOMBRE DE CP A PRENDRE EN CONSIDERATION EST SUPERIEUR AU NOMBRE DE VARIABLES  ')
break
end
% OPTION OF PROBABILISTIC MODELS TO SIMULATE 
% 1=Log Normale  2=Gene-Extre-Va(GEV) 3=GAMMA 4=Goodrich Distributions
IC = [2  2  2  2 ]; % CHOIX DES LOIS D'AJUSTEMENT DES CP REDUITES
% IC is equal to number of NPC, here  = 4
IR = [2 2 2 2 2 2 2 2 2 2 2 2]; % CHOIX DES LOIS D'AJUSTEMENT DES RESIDUS
%('MOYENNES DES VARIABLES'):  XMB = mean (V);
%('ECART TYPE  DES VARIABLES'): XETB = std (V);

% ITR  TRANSFORMATION OF DATA BEFORE SIMULATION
%   if ITR==1; disp('NO TRANSFORMATION  AUCUNE TRANSFORMATION DE LA VARIABLE'), X=V;
%   elseif ITR==2; disp('SQUARE-ROOT TRANSFORMATION OF OBSERVED DATA'), X=sqrt(V);
%   elseif ITR==3; disp('TRANSFORMATION LOG DECIMALE DE LA VARIABLE'),  X=log10(V);    end
% TYPE DE TRANSFORMATION DE LA VARIABLE
% 1=AUCUNE    2:RACINE CARREE   3:LOG DECIMALE

ITR=2; %  SQUARE-ROOT TRANSFORMATION OF OBSERVED DATA Variable Transformees en Racine carrees
[V,COR, FF, FFT, RES,DRS, Xsim] = HYDROSIM(DATA,V,TEXT,L,C,IGR,ITR,LS,NCP,IC,IR);